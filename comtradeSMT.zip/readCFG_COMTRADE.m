function data = readCFG_COMTRADE(filename)

fid = fopen(filename); % open the configuration file

qq = fgetl(fid); % read line 1
ww = textscan(qq,'%s','delimiter',','); % get individual entries

data.station_name = ww{:}{1};
data.recording_device = ww{:}{2};

if numel(ww{:})==3
    data.revision_year = ww{:}{3};
else
    data.revision_year = '';
end

qq = fgetl(fid); % read line 2
ww = textscan(qq,'%s','delimiter',','); % get individual entries

data.total_channels = str2double(ww{:}{1});
data.total_analog = str2double(ww{:}{2}(1:end-1));
data.total_digital = str2double(ww{:}{3}(1:end-1));

% channel information

for la = 1:data.total_analog % loop through each analog channel
    
    qq = fgetl(fid); % read line
    ww = textscan(qq,'%s','delimiter',','); % get individual entries
    
    data.analog.An(la,1) = ww{:}(1);

    eea = ww{:}(2);
    eeb = strrep(eea,'(','_'); % replace brackets with underscore
    eec = strrep(eeb,')','_'); % replace brackets with underscore
    eed = strrep(eec,'/','_'); % replace forward slashes with underscore
    
    data.analog.ch_id(la,1) = eed;
    
    data.analog.ph(la,1) = ww{:}(3);
    data.analog.ccbm(la,1) = ww{:}(4);
    data.analog.uu(la,1) = ww{:}(5);
    data.analog.a(la,1) = str2double(ww{:}(6));
    data.analog.b(la,1) = str2double(ww{:}(7));
    data.analog.skew(la,1) = str2double(ww{:}(8));
    data.analog.min(la,1) = str2double(ww{:}(9));
    data.analog.max(la,1) = str2double(ww{:}(10));
    data.analog.primary(la,1) = str2double(ww{:}(11));
    data.analog.secondary(la,1) = str2double(ww{:}(12));
    data.analog.PS(la,1) = ww{:}(13);
    
end


for ld = 1:data.total_digital % loop througfh digital channels
    
    qq = fgetl(fid); % read line
    ww = textscan(qq,'%s','delimiter',','); % get individual entries
    
    data.digital.Dn(ld,1)       = ww{:}(1);
    
    eea = ww{:}(2);
    
    eeb = strrep(eea,'*',['TEMP',num2str(ld)]); % replace *
    eec = strrep(eeb,'/','_');
    
    data.digital.ch_id(ld,1)   = eec;
    data.digital.ph(ld,1)       = ww{:}(3);
    data.digital.ccbm(ld,1)   = ww{:}(4);
    data.digital.y(ld,1)        = str2double(ww{:}(5));
    
end

% line frequency

qq = fgetl(fid); % read line
ww = textscan(qq,'%s','delimiter',','); % get individual entries

data.lf = str2double(ww{:});

% number of rates

qq = fgetl(fid); % read line
ww = textscan(qq,'%s','delimiter',','); % get individual entries

data.numrates = str2double(ww{:});

% samp, endsamp

qq = fgetl(fid); % read line
ww = textscan(qq,'%s','delimiter',','); % get individual entries

data.samp = str2double(ww{:}{1});
data.endsamp = str2double(ww{:}{2});


% startdate starttime

qq = fgetl(fid); % read line
ww = textscan(qq,'%s','delimiter',','); % get individual entries

data.startdate = ww{:}{1};
data.starttime = ww{:}{2};

% triggerdate triggertime

qq = fgetl(fid); % read line
ww = textscan(qq,'%s','delimiter',','); % get individual entries

data.triggerdate = ww{:}{1};
data.triggertime = ww{:}{2};

% filetype

qq = fgetl(fid); % read line
ww = textscan(qq,'%s','delimiter',','); % get individual entries

data.filetype = ww{:}{1};


% timemult

qq = fgetl(fid); % read line
ww = textscan(qq,'%s','delimiter',','); % get individual entries

data.timemult = str2double(ww{:}{1});






    
