function [data,dataCFG] = cad_read(filename)

dataCFG = readCFG_COMTRADE(strjoin([filename,'.CFG'],''));
data = readDAT_COMTRADE(strjoin([filename,'.DAT'],''),dataCFG);
[a,b,c] = loadandgraph(data,dataCFG);

end

