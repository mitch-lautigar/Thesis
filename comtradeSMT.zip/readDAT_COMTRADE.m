function data = readDAT_COMTRADE(filename,dataCFG)

fid = fopen(filename); % open the data file

nn = repmat('%n',1,dataCFG.total_channels+2); % column format

ww = textscan(fid,nn,'delimiter',','); % read in the data


data.time = ww{2}*1e-6;

for la = 1:dataCFG.total_analog

    data.analog.(dataCFG.analog.ch_id{la}) = dataCFG.analog.a(la)*ww{la+2} + dataCFG.analog.b(la);
    
end

for ld = 1:dataCFG.total_digital

    data.digital.dataCFG.digital.ch_id{ld} = ww{la+ld+2};
    
end

end

